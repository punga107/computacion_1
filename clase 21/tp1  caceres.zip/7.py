# ej 7


def near(num):
    if 100 >= num > 89:
        print('true')
    elif num > 101 or num >= 89:
        print('false')
    return


print(near(100))
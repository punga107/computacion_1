#ej 3


def suma(num1, num2):
    if num1 == num2:
        first = num1 + num2
        total = first * 2
        print(total)
    elif num1 != num2:
        sum = num1 + num2
        print(sum)
    return


print(suma(2, 3))

# ej 4
num2 = 21


def diferencia(num, num2):
    if num2 > num:
        total = num2 - num
        print(total)
    elif num >= num2:
        total2 = num2 * 2
        print(total2)
    return

print(diferencia(21, 21))
